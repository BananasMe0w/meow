<!DOCTYPE html>
<html lang="th" dir="ltr">
  <head>
    <?php
    include "head.php";
     ?>
  </head>
  <body>
    <?php
      include "chk.php";
      include "container.php";
    ?>

    <?php
    include "footer.php";
    ?>
  </body>
</html>
