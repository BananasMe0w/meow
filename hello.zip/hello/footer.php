<script src="js/jquery.js" charset="utf-8"></script>
<script src="js/bootstrap.js" charset="utf-8"></script>
